package com.example.mobilediagonstictool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    CardView display, hardware, camera, sound, network, ram,
            sensor, battery, gps, info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display =(CardView) findViewById(R.id.c1);
        hardware = (CardView) findViewById(R.id.c2);
        camera = (CardView) findViewById(R.id.c4);
        sound = (CardView) findViewById(R.id.c6);
        network = (CardView) findViewById(R.id.c7);
        ram = (CardView) findViewById(R.id.c5);
        sensor = (CardView) findViewById(R.id.c8);
        battery = (CardView) findViewById(R.id.c3);
        gps = (CardView) findViewById(R.id.c9);
        info = (CardView) findViewById(R.id.c10);





        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        hardware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        sensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        ram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
       network.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
       battery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
       info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });






    }

    private void openAnother_Activity() {
        Intent intent = new Intent(this,Another_Activity.class);
        startActivity(intent);
    }

}